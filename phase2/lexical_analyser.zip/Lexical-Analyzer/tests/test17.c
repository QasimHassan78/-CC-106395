#define A 10 
int a = 5;